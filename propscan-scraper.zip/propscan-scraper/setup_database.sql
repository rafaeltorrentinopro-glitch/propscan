-- ══════════════════════════════════════
-- PropScan — Tables Supabase
-- Coller dans SQL Editor de Supabase
-- ══════════════════════════════════════

-- Table des annonces
CREATE TABLE IF NOT EXISTS annonces (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  source TEXT NOT NULL,
  titre TEXT NOT NULL,
  prix INTEGER DEFAULT 0,
  surface INTEGER DEFAULT 0,
  pieces INTEGER DEFAULT 0,
  ville TEXT DEFAULT '',
  code_postal TEXT DEFAULT '',
  arrondissement TEXT DEFAULT '',
  description TEXT DEFAULT '',
  image_url TEXT DEFAULT '',
  url_original TEXT DEFAULT '',
  dpe TEXT DEFAULT '',
  type_bien TEXT DEFAULT '',
  rentabilite DECIMAL(5,2) DEFAULT 0,
  cashflow INTEGER DEFAULT 0,
  prix_m2 INTEGER DEFAULT 0,
  score DECIMAL(3,1) DEFAULT 0,
  est_particulier BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des utilisateurs / abonnements
CREATE TABLE IF NOT EXISTS users (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  nom TEXT DEFAULT '',
  prenom TEXT DEFAULT '',
  plan TEXT DEFAULT 'essentiel',
  analyses_ce_mois INTEGER DEFAULT 0,
  logo_url TEXT DEFAULT '',
  agence_nom TEXT DEFAULT '',
  agence_couleur TEXT DEFAULT '#1A1A1A',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des favoris
CREATE TABLE IF NOT EXISTS favoris (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  annonce_id UUID REFERENCES annonces(id) ON DELETE CASCADE,
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des alertes
CREATE TABLE IF NOT EXISTS alertes (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  nom TEXT NOT NULL,
  ville TEXT DEFAULT '',
  type_bien TEXT DEFAULT '',
  prix_max INTEGER DEFAULT 0,
  surface_min INTEGER DEFAULT 0,
  rentabilite_min DECIMAL(4,2) DEFAULT 0,
  active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Table des dossiers PDF générés
CREATE TABLE IF NOT EXISTS dossiers (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  annonce_id UUID REFERENCES annonces(id),
  titre TEXT NOT NULL,
  data JSONB DEFAULT '{}',
  lien_partage TEXT DEFAULT '',
  vues INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index pour performances
CREATE INDEX IF NOT EXISTS idx_annonces_ville ON annonces(ville);
CREATE INDEX IF NOT EXISTS idx_annonces_prix ON annonces(prix);
CREATE INDEX IF NOT EXISTS idx_annonces_source ON annonces(source);
CREATE INDEX IF NOT EXISTS idx_annonces_created ON annonces(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_favoris_user ON favoris(user_id);

-- RLS (Row Level Security) — chaque user voit seulement ses données
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE favoris ENABLE ROW LEVEL SECURITY;
ALTER TABLE alertes ENABLE ROW LEVEL SECURITY;
ALTER TABLE dossiers ENABLE ROW LEVEL SECURITY;

-- Annonces sont publiques (tout le monde les voit)
ALTER TABLE annonces ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Annonces publiques" ON annonces FOR SELECT USING (true);
CREATE POLICY "Insert annonces scraper" ON annonces FOR INSERT WITH CHECK (true);
CREATE POLICY "Update annonces scraper" ON annonces FOR UPDATE USING (true);

-- Policies users
CREATE POLICY "Users voient leur profil" ON users FOR SELECT USING (auth.uid()::text = id::text);
CREATE POLICY "Users modifient leur profil" ON users FOR UPDATE USING (auth.uid()::text = id::text);
CREATE POLICY "Insert user à la création" ON users FOR INSERT WITH CHECK (true);

-- Policies favoris
CREATE POLICY "Favoris par user" ON favoris FOR ALL USING (auth.uid()::text = user_id::text);

-- Policies alertes
CREATE POLICY "Alertes par user" ON alertes FOR ALL USING (auth.uid()::text = user_id::text);

-- Policies dossiers
CREATE POLICY "Dossiers par user" ON dossiers FOR ALL USING (auth.uid()::text = user_id::text);
CREATE POLICY "Dossiers partagés publics" ON dossiers FOR SELECT USING (lien_partage != '');

-- Quelques annonces de démo pour tester
INSERT INTO annonces (source, titre, prix, surface, pieces, ville, code_postal, description, url_original, type_bien, rentabilite, cashflow, prix_m2, score, est_particulier, dpe)
VALUES
('SeLoger', 'T2 Vue mer — Marseille 13003', 59999, 36, 2, 'Marseille', '13003', 'Beau T2 avec vue mer, idéal investissement locatif, proche transports.', 'https://www.seloger.com', 'Appartement', 8.40, 187, 1666, 8.6, true, 'C'),
('PAP', 'Immeuble 4 lots — Toulouse Hypercentre', 320000, 180, 10, 'Toulouse', '31000', 'Immeuble de rapport 4 lots en plein centre. Excellent rendement locatif.', 'https://www.pap.fr', 'Immeuble', 9.30, 680, 1777, 9.1, true, 'D'),
('LeBonCoin', 'Studio rénové — Lyon 7e', 89000, 28, 1, 'Lyon', '69007', 'Studio entièrement rénové, cuisine équipée, parquet. Idéal LMNP.', 'https://www.leboncoin.fr', 'Studio', 7.10, 124, 3178, 7.9, true, 'B'),
('SeLoger', 'T3 Hypercentre — Bordeaux', 142000, 54, 3, 'Bordeaux', '33000', 'Beau T3 en hypercentre, immeuble pierre, double vitrage.', 'https://www.seloger.com', 'Appartement', 6.80, 89, 2629, 7.4, false, 'D'),
('BienIci', 'Maison T4 avec jardin — Montpellier', 198000, 110, 4, 'Montpellier', '34000', 'Maison familiale avec grand jardin, garage, proche école.', 'https://www.bienici.com', 'Maison', 8.10, 342, 1800, 8.1, false, 'C'),
('LeBonCoin', 'T2 Meublé LMNP — Nice Centre', 145000, 38, 2, 'Nice', '06000', 'T2 meublé idéal LMNP, dans résidence avec gardien. Forte demande locative.', 'https://www.leboncoin.fr', 'Appartement', 7.50, 201, 3815, 8.0, true, 'B'),
('PAP', 'Immeuble 6 lots — Nantes', 480000, 280, 12, 'Nantes', '44000', 'Immeuble de rapport 6 lots entièrement loués. Rendement net 7%.', 'https://www.pap.fr', 'Immeuble', 8.80, 920, 1714, 8.9, true, 'E'),
('SeLoger', 'Studio Étudiant — Rennes', 68000, 22, 1, 'Rennes', '35000', 'Studio idéalement situé proche fac, forte demande étudiante.', 'https://www.seloger.com', 'Studio', 9.10, 156, 3090, 8.7, false, 'C');

SELECT COUNT(*) as annonces_importées FROM annonces;
